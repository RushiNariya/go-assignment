Day8
- Fix data race in waitGroup.go
- Create and consume our custom log package
- Understand log levels

Day9
- Consume net/http package as a client

Day10
- http server
- middlewares
- passing request scoped data using context

Day10
- Postgres
- Gin endpoints
- Structure code for extensibility

Day11
- taskfile
- go mod tidy
- config && env variables
- JWT token, login
- DB migration